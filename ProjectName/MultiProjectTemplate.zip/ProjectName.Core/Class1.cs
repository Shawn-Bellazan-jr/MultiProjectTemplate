﻿namespace ProjectName.Core
{
    public class Class1
    {

    }
}
